
#ifndef _CHINESE_H
#define _CHINESE_H

#include <iostream>
#include <string.h>
#include <unistd.h>

using namespace std;

class Chinese{
public:
	void eating(void);
	void wearing(void);
	void driving(void);
	~Chinese();
};

#endif

