
#ifndef _ENGLISHMAN_H
#define _ENGLISHMAN_H

#include <iostream>
#include <string.h>
#include <unistd.h>

using namespace std;

class Englishman {
public:
	void eating(void);
	void wearing(void);
	void driving(void);
	~Englishman();
};

#endif

