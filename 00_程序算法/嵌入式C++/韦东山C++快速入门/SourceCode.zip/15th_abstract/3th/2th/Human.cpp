
#include "Human.h"

void Human::setName(char *name) 
{
	this->name = name;
}

char *Human::getName(void) 
{
	return this->name;
}


